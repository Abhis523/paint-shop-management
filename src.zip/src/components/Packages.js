import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import '../css/Activities.css'
import '../css/packages.css'
export default class extends Component {
    render() {
        return (
            <div className='Room container'>

                <div class="wrapper">

                </div>

                {/* <!--Navigation Code starts here-->

<!--Navigation Code Ends Here--> */}
                <br />
                <br />
                <br />



                <div>
                    {/* <h1> Enjoy Your Holidays In Sinhagad!</h1> */}
                </div>

                <br />
                <br />




                <div class="container border border-1 text-center Abc">

                    <br />

                    <div class="row">





                        <div class=" xyz ">
                            <h1 className='abc' >ONE DAY PACKAGE(9AM TO 5PM)</h1>

                            <p> Per adult:-900/-
                                <br />
                                Per child:- 650/-(Age limit 5 to 10yrs)
                                <br />
                                Includes- breakfast ,lunch with sweet ,high tea with snacks</p>


                        </div>



                    </div>



                    <h6>__________________________________________________________________________________________________________________________________________________
                    </h6>

                    <br />


                    <div class="row">

                        <div class=" xyz ">
                            <h1 className='abc' >HALF DAY PACKAGE (12.30 PM TO 5PM )</h1>

                            <p> Per adult :-750/-<br />
                                Per child :-500/-(age limit 5 to 10 yrs)<br />s
                                Includes :lunch /dinner with sweet ,high tea with snacks</p>


                        </div>


                    </div>


                    <h6>__________________________________________________________________________________________________________________________________________________
                    </h6>

                    <br />
                    <br />







                    <div class="row">


                        <div class=" xyz ">
                            <h1 className='abc' >OVER NIGHT STAY PACKAGE (12NOON TO 10 AM )</h1>

                            <p> AC GAZEBO ROOMS :-2200/-PER PERSON
                                1100/-PER CHILD<br/>
                                2BH BUNGLOW:-2000/-PER PERSON<br/>
                                1000/-PER CHILD<br/>
                                NON AC ROOMS:-2000/-PER PERSON<br/>
                                1000/- PER CHILD<br/>
                                INCLUDES :-Welcome drink,Lunch with sweet,High tea with snacks,Dinner, Morning Breakfast
                                AMENITIES FOR ALL PACKAGES:-Swimming pool with changing rooms,Indoor/Outdoor games/Children play area ,Multipuropse hall etc.
                                T&C APPLY</p>


                        </div>


                    </div>
                    <br />
                    <br />

                    <h6>__________________________________________________________________________________________________________________________________________________
                    </h6>













































                </div>
                <br />
                <br />
                <br />


            </div>
        )
    }
}
